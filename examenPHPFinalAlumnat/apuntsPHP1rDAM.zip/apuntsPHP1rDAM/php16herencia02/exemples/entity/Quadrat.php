<?php
class Quadrat extends Poligon{
  function calcul() {
	  echo "Àrea d'un quadrat: a = costat * costat <br>";
  }
}