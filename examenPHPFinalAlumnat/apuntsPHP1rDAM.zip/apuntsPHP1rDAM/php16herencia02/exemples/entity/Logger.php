<?php
//definim la interfície
interface Logger {
    public function log($missatge);
}