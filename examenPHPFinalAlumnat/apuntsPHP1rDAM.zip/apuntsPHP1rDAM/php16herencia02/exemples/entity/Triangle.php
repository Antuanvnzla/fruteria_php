<?php

class Triangle extends Poligon{
  function calcul () {
  	echo "Àrea d'un triangle: a = (base * altura) / 2 <br>";
  }
}

