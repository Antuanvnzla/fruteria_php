<?php
//classe abstracta pare animal

abstract class Animal { 
  abstract function so();     
}   