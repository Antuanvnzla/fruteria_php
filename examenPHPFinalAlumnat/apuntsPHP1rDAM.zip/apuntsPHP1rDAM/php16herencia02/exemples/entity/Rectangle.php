<?php
class Rectangle extends Poligon{
  function calcul()  {
  	echo "Àrea d'un rectangle: a = base * altura <br>";
  }
}