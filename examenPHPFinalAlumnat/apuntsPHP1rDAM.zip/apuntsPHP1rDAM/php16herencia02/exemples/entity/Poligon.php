<?php
// Definim la classe abstracta
abstract class Poligon{
  abstract function calcul();  // declarem mètode abstracte
}